// let t = function testFunction(x,y){
//     let z = (x+y);
//     return z;
// }

// console.log(t(10,20));


// function testFunction(x = 10 , y){
//     let z = x + y;
//     return z;
// }

// console.log(testFunction(4));

// Basic function
function firstFunction(){
    console.log("Basic Function");
}

firstFunction();


// Anonymous Function
let k = function(x , y){
    let z = x + y;
    console.log(z);
}
console.log(k(2,4));

// Arrow Function

let t = () => {
    console.log("Arrow function.")
}

t();



